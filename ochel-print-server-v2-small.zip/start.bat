@echo off
title O'chel Foods Print Server
cd /d "%~dp0"

echo ================================================
echo       O'CHEL FOODS - PRINT SERVER v2
echo ================================================
echo.

:: Check if Node.js is installed
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed on this PC.
    echo.
    echo Please do the following:
    echo   1. Open your browser and go to: https://nodejs.org
    echo   2. Click the big green "LTS" download button
    echo   3. Run the installer ^(click Next through everything^)
    echo   4. Restart this PC
    echo   5. Then double-click start.bat again
    echo.
    pause
    exit /b 1
)

echo Node.js found. Starting print server...
echo.
node print-server.js
echo.
echo ================================================
echo  Print server stopped. See any error above.
echo  Take a photo and send it to your developer.
echo ================================================
pause
